import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

export const store = new Vuex.Store({
    state:{
        userId: '',
        accessToken: '',
        mapperId: ''
    },
    mutations: {
        setUserId(state, userId){
            state.userId = userId;
        },
        setAccessToken(state, accessToken){
            state.accessToken = accessToken;
            Vue.prototype.$axios.defaults.headers.common['Authorization'] = accessToken;
        },
        setMapperId(state, mapperId){
            state.mapperId = mapperId;
        }
    },
    actions : {
        setUserAccount(context, payload){
            context.commit("setAccessToken", palyload.token);
            context.commit("setUserId", payload.userId);
        },
        setOrderMapperId(context, mapperId){
            context.commit("setMapperId", mapperId);
        }
    }
});