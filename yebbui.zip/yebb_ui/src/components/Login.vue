<template>
   
    <div id="login" class="container">
        <h1 class="display-2  text-center">SHOPMIND</h1>
        <div class="form-group row">
            <label for="loginId" class="col-sm-2 col-form-label">ID</label>
            <div class="col-sm-5">
            <input type="text" class="form-control" placeholder="loginId" id="loginId">
            </div>
        </div>
        <div class="form-group row">
            <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
            <div class="col-sm-5">
            <input type="password" class="form-control" id="inputPassword" placeholder="Password">
            </div>
        </div>
        <div class="container">
            <button type="button" class="btn btn-primary">Login</button>
        </div>
    </div>
</template>

<script>
export default {
    created(){
        console.log('login. vue created')
    }
}
</script>