
<template>
    <div id="products" class="container">
        <div class="row">
            <div class="col">
                <h5>Products </h5>
            </div>
            <div class="col">
        
            </div>
            <div class="col">
                <button type="submit" class="btn btn-primary mb-2" v-on:click="getProductList">Loading</button>
            </div>
        </div>
        <table id="productList" class="table table-striped table-sm table-responsive-md">
        <thead class="thead-dark">
            <tr>
            <th scope="col">#</th>
            <th scope="col">Product</th>
            <th scope="col">Count</th>
            <th scope="col">Price</th>
            </tr>
        </thead>
        <tbody>
          <template v-for="(product, index) in products" >
            <tr>
            <td>{{ index+1 }}</td>
            <td>{{ product.prodtName}}</td>
            <td>{{ product.count}}</td>
            <td>{{ product.price | numeral('0,0') }}</td>
            </tr>
          </template>
        </tbody>
        </table> 
    </div>
</template>

<script>
var datas = [
        { prodtCode: 'A', prodtName: 'Foo', count: '2', price: '100' },
        { prodtCode: 'B', prodtName: 'Bar', count: '5', price: '200' },
        { prodtCode: 'C', prodtName: 'Bar', count: '5', price: '200' },
        { prodtCode: 'D', prodtName: 'Bar', count: '5', price: '200' },
        { prodtCode: 'E', prodtName: 'Bar', count: '5', price: '200' }
      ];
export default {
  name: 'ProductsList',
  data() { 
      return{
        products: []  
      }
  },    
  created(){
      console.log('ProdList.vue created')
  },
  /*mounted: function(){
      this.getProductList();
  },*/
  methods: {
    getProductList: function () {
        console.log('getProductList called')
       // this.products = datas;
        this.$axios.get('/products').then((response) => {
            //console.log(response.data);
            this.products = response.data;
            //console.log("response.length :"+response.data.length);
            console.log("this.products :"+this.products);
            console.log("this.products length :"+this.products.length);
            //return this.products;
        })
        .catch(function (error) {
            console.log(error);
        }); 
        
    },
    formatPrice(value) {
        let val = (value/1).toFixed(2).replace('.', ',')
        return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")

        //val
    }
  }
}
</script>
