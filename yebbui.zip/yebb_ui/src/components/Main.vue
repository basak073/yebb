<template>
    <div id="controlPane" class="container">
        <div class="row">
            <div class="col">
                <button type="button" class="btn btn-outline-primary" v-on:click="mapProduct1">Mapping (Rule 1)</button>
            </div>
            <div class="col">
                <button type="button" class="btn btn-outline-primary disabled" v-on:click="mapProduct2" disabled>Mapping (Rule 2)</button>
            </div>
            <div class="col">
                <button type="button" class="btn btn-outline-primary" v-on:click="makeOrder">Order</button>
            </div>
        </div>
        <div class="row">
                <table class="table table-borderless">
                <tbody>
                    <tr>
                    <td scope="col"></td>
                    <td scope="col"></td>
                    <td scope="col"></td>
                    <td scope="col"></td>
                    </tr>
                </tbody>
                </table>
        </div>
        <div class="container">
        <div class="row">
            <div class="col">
                <h5>Status </h5>
            </div>
            <div class="col">
        
            </div>
            <div class="col">
                
            </div>
        </div>



        
        <table id="orderStatus" class="table table-hover table-sm table-responsive-md">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>            
            <th scope="col">Product</th>
            <th scope="col">Order</th>
            <th scope="col">Purchased</th>
            <th scope="col">Payment</th>
            <th scope="col">Credit</th>
            <th scope="col">Status</th>
            </tr>
        </thead>
                <tbody v-for="state in status">
                    <tr>
                    <td scope="col">{{ state.userId }}</td>
                    <td scope="col">{{ state.name }}</td>
                    <td scope="col">{{ state.prdtName }}</td>
                    <td scope="col">{{ state.order | numeral('0,0') }}</td>
                    <td scope="col">{{ state.purchased | numeral('0,0') }}</td>
                    <td scope="col">{{ state.payment | numeral('0,0') }}</td>
                    <td scope="col">{{ state.credit | numeral('0,0') }}</td>
                    <td scope="col">{{ state.status }}</td>                
                    </tr>
                </tbody>
        </table>  
        
        </div>
        
    <products ref="products"></products>
    <buyers ref="buyers"></buyers>    
    </div>
</template>

<script>
import products from './ProductsList.vue'
import buyers from './BuyersList.vue'


const orderUrl =  "";

var datas = [
        { userId: 'him2min', name: '권혁민', prdtName: '샘물 무스 캔디 틴트 03 당근 무스 8g', order: '15', count: '12', credit: '100' },
        { userId: 'hongkildong', name: '홍길동', prdtName: '홍이장군로얄1단계(15ml*30포)', order: '15', count: '15', credit: '200' },
        { userId: 'kim', name: '김영민', prdtName: '디어달링워터젤틴트 5호 RD301리얼레드 4.5g', order: '15', count: '10', credit: '200' }
      ];

var statdata = [
        { userId: 'him2min', name: '권혁민', prdtName: '샘물 무스 캔디 틴트 03 당근 무스 8g', order: '15', purchased: '12', payment: '100', credit: '300', status: '...' },
        { userId: 'hongkildong', name: '홍길동', prdtName: '홍이장군로얄1단계(15ml*30포)', order: '15', purchased: '15', payment: '200', credit: '300', status: '...' },
        { userId: 'kim', name: '김영민', prdtName: '디어달링워터젤틴트 5호 RD301리얼레드 4.5g', order: '15', purchased: '10', payment: '200', credit: '300', status: '...' }

      ];     

export default {
  data() {
    return {
      status: [],
      polling: null
    }
  },
  components:{
      products,
      buyers
  },  
  created(){
     console.log('Main controlpane created')
  },
  methods: {
    makeOrder: function () {

        console.log('makeOrder called')
        console.log(" this.$store.mapperId "+this.$store.state.mapperId);
        if(this.$store.state.mapperId !='' ){
            
            this.status = statdata;
            this.pullStatus();
        }else{
            alert("Mapper ID not ready!")
        }
        
        /*
        this.$axios.get('/products').then((response) => {
            //console.log(response.data);
            this.products = response.data;
            //console.log("response.length :"+response.data.length);
            console.log("this.products :"+this.products);
            console.log("this.products length :"+this.products.length);
            //return this.products;
        })
        .catch(function (error) {
            console.log(error);
        }); 
        */
    },
    mapProduct1: function() {
        console.log("Mapping 1 called")
        if(this.$refs.products.products.length == 0 
            || this.$refs.buyers.users.length == 0){
                alert("Products list or buyers list is empty")
        }else{

            this.$axios.get('/mapping').then((response) => {
                console.log('mapping data....'+response.data);
                this.$refs.buyers.mappings = response.data;
                this.$refs.buyers.mappingFlag = true;
                this.$refs.buyers.buyerFlag = false;

            })
            .catch(function (error) {
                console.log(error);
            });

            //this.$refs.buyers.users = datas;
            this.$store.dispatch('setOrderMapperId', '1001') //TODO.... Fixit
        }        
        
    },
    mapProduct2: function() {
        console.log("Mapping 2 called")
        //$refs.products.getProductList();
    },
    pullStatus: function(){
        this.polling = setInterval(() => {
            console.log("pullStatus....")

		}, 5000)
    },
    beforeDestroy () {
	    clearInterval(this.polling)
    },
    formatPrice(value) {
        let val = (value/1).toFixed(2).replace('.', ',')
        return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>


