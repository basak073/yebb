<template>
    <div id="buyers" class="container">
        <div v-if="buyerFlag">
        <div class="row">
            <div class="col">
                <h5>Buyers </h5>
            </div>
            <div class="col">
        
            </div>
            <div class="col">
                <button type="submit" class="btn btn-primary mb-2" v-on:click="getBuyerList">Loading</button>
            </div>
        </div>
        <table id="buyerList" class="table table-striped table-sm table-responsive-md">
        <thead class="thead-dark">
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>            
            <th scope="col">Count</th>
            <th scope="col">Credit</th>
            </tr>
        </thead>
        <tbody>
            <template v-for="user in users" >
            <tr>
            <th>{{ user.userId }}</th>
            <td>{{ user.userName }}</td>            
            <td>{{ user.count | numeral('0,0') }}</td>
            <td>{{ user.credit | numeral('0,0') }}</td>
            </tr>
            </template>
        </tbody>
        </table>
        </div>
        <div v-if="mappingFlag">
        <div class="row">
            <div class="col">
                <h5>Buyer-Product mapping result </h5>
            </div>
        </div>            
        <table id="mappingList" class="table table-striped table-sm table-responsive-md">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>            
            <th scope="col">Product</th>
            <th scope="col">Price</th>
            <th scope="col">Order</th>
            <th scope="col">Credit</th>
            <th scope="col">Temp Date</th>
            <th scope="col">Departue</th>
            </tr>
        </thead>
            <tbody v-for="mapping in mappings">
                <tr>
                <td scope="col">{{ mapping.userId }}</td>
                <td scope="col">{{ mapping.userName }}</td>
                <td scope="col">{{ mapping.prodtName }}</td>
                <td scope="col">{{ mapping.prodtPrice | numeral('0,0') }}</td>
                <td scope="col">{{ mapping.orderCount | numeral('0,0') }}</td>
                <td scope="col">{{ mapping.userCredit | numeral('0,0') }}</td>
                <td scope="col">{{ mapping.tmpDepDate }}</td>
                <td scope="col">{{ mapping.depDate }}</td>
                </tr>
            </tbody>
        </table>
        </div>
    </div>
</template>
<script>
var datas =  [
        { userId: 'sam1', name: 'Sam', count: '12', credit: '100' },
        { userId: 'kwon2', name: 'Kwon', count: '25', credit: '200' },
        { userId: 'kim3', name: 'Kim', count: '35', credit: '200' },
        { userId: 'park2', name: 'Park', count: '15', credit: '200' },
        { userId: 'jong', name: 'Jong', count: '55', credit: '200' },
        { userId: 'jong3', name: 'Jong3', count: '55', credit: '200' }
      ];
export default {
  name: 'BuyersList',
  data: function () {
    return {
      users: [],
      mappings: [],
      mappingFlag: false,
      buyerFlag: true
    }
  },
  created(){
      console.log('BuyerList.vue created');

 /*     this.$http.get('/users')
      .then((response) => {
        this.users = response.data
      })*/
  },
  /*mounted: function(){
      this.getBuyerList();
  },*/
  methods: {
    getBuyerList: function () { 
        //var _this = this;
        console.log('getBuyerList called')
        this.$axios.get('/users').then((response) => {
            this.users = response.data;
            //console.log("response.data.length :"+response.data.length);
            console.log("this.users :"+this.users);
            console.log("this.users.length :"+this  .users.length);
        })
        .catch(function (error) {
            console.log(error);
        });
       
    },
    formatPrice(value) {
        let val = (value/1).toFixed(2).replace('.', ',')
        return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
    }

  }
}


</script>
