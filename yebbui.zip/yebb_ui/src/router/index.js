import Vue from 'vue'
import VueRouter from 'vue-router'
import Main from '@/components/Main'
import ProductsList from '@/components/ProductsList'
import BuyersList from '@/components/BuyersList'
import Login from '@/components/Login' 
//import { store } from "./store";


Vue.use(VueRouter)

const router = new VueRouter({
    
  mode: 'history',
  base: '/',
  routes: [
    {
        path: '*',
        name: 'Default',
        component: Main
    },
    {
        path: '/login',
        name: 'Login',
        component: Login
    },
    {
        path: '/main',
        name: 'Main',
        component: Main /*,
        beforeEnter(from, to, next){
            if(store.state.accessToken){
                next();
            }else{
                next('/login');
            }
        }*/
        ,children: [
        {
            path: '/pdlist',
            component: ProductsList,
        },
        {
            path: '/buyers',
            component: BuyersList
        }
       ]
    },

/*    
    ,{
        path: '/products',
        name: 'ProductsList',
        component: ProductsList
    },{
        path: '/buyers',
        name: 'BuyersList',
        component: BuyersList
    }*/
  ]
})

export default router
