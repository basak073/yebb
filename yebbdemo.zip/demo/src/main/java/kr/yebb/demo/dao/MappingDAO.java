package kr.yebb.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import kr.yebb.demo.vo.MappingVO;

@Repository
public class MappingDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<MappingVO> getMappedList(){
		
		System.out.println("MappingDAO");
		String query = "SELECT USERID, USERNAME, PRODTID, PRODTNAME, PRODTPRICE, ORDERCOUNT, USERCREDIT, TMPDEPDATE, DEPDATE FROM MAPPEDRESULT ; ";
		RowMapper<MappingVO> rowMapper = new BeanPropertyRowMapper<MappingVO>(MappingVO.class);
		
		return this.jdbcTemplate.query(query, rowMapper);
	}
}
