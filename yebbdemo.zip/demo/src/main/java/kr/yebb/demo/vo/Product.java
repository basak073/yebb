package kr.yebb.demo.vo;

import java.io.Serializable;

public class Product implements Serializable {

	private String prodtId;
	private String prodtName;
	private int count;
	private long price;
	public String getProdtId() {
		return prodtId;
	}
	public void setProdtId(String prodtId) {
		this.prodtId = prodtId;
	}
	public String getProdtName() {
		return prodtName;
	}
	public void setProdtName(String prodtName) {
		this.prodtName = prodtName;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	
	
	
}
