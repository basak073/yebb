package kr.yebb.demo.vo;

import java.io.Serializable;

public class MappingVO implements Serializable {

   
    private String userId;
    private String userName;
    private String prodtName;
    private String prodtId;
    private long prodtPrice;
    private int orderCount;
    private long userCredit;
    private String tmpDepDate;
    private String depDate;
    
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getProdtName() {
		return prodtName;
	}
	public void setProdtName(String prodtName) {
		this.prodtName = prodtName;
	}
	public String getProdtId() {
		return prodtId;
	}
	public void setProdtId(String prodtId) {
		this.prodtId = prodtId;
	}
	public long getProdtPrice() {
		return prodtPrice;
	}
	public void setProdtPrice(long prodtPrice) {
		this.prodtPrice = prodtPrice;
	}
	public int getOrderCount() {
		return orderCount;
	}
	public void setOrderCount(int orderCount) {
		this.orderCount = orderCount;
	}
	public long getUserCredit() {
		return userCredit;
	}
	public void setUserCredit(long userCredit) {
		this.userCredit = userCredit;
	}
	public String getTmpDepDate() {
		return tmpDepDate;
	}
	public void setTmpDepDate(String tmpDepDate) {
		this.tmpDepDate = tmpDepDate;
	}
	public String getDepDate() {
		return depDate;
	}
	public void setDepDate(String depDate) {
		this.depDate = depDate;
	}
    
    
}
