package kr.yebb.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import kr.yebb.demo.vo.Product;

@Repository
public class ProductDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<Product> getProudctList(){
		
		System.out.println("ProductDAO");
		String query = "SELECT PRODTID, PRODTNAME, COUNT, PRICE FROM PRODUCT; ";
		RowMapper<Product> rowMapper = new BeanPropertyRowMapper<Product>(Product.class);
		
		return this.jdbcTemplate.query(query, rowMapper);
	}
}
