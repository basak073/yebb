package kr.yebb.demo.svc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.yebb.demo.dao.UserDAO;
import kr.yebb.demo.vo.User;

@Service
public class UserSVC {
	
	@Autowired
	private UserDAO userDAO;

	
	public List<User> getUserLsit(){
		
		return userDAO.getUserist();
	}
}
