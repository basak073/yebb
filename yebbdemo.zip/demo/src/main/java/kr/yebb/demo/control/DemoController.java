package kr.yebb.demo.control;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import kr.yebb.demo.svc.MappingSVC;
import kr.yebb.demo.svc.ProductSVC;
import kr.yebb.demo.svc.UserSVC;
import kr.yebb.demo.vo.MappingVO;
import kr.yebb.demo.vo.Product;
import kr.yebb.demo.vo.User;

@RestController
public class DemoController {

	@Autowired
	ProductSVC productService;
	
	@Autowired
	UserSVC userService;
	
	@Autowired
	MappingSVC mappService;
	
	@RequestMapping("/products")	
	public List<Product> getProducts() {
		
		//DemoBean bean = 
		List<Product> retlist = productService.getProuductList();
		
		/*
		 * Product product = new Product();
		 * 
		 * product.setProdtId("101"); product.setProdtName("sample name");
		 * product.setCount(1); product.setPrice(2300);
		 */	
		
		/*
		 * ArrayList<Product> retlist = new ArrayList<Product>();
		 * 
		 * 
		 * retlist.add(product);
		 */
		
		
		return retlist;
	}
	
	@RequestMapping("/users")
	public List<User> getUsers(){
		List<User> retlist = userService.getUserLsit();
		return retlist;
	}
	
	@RequestMapping("/mapping")
	public List<MappingVO> getMappedList(){
		List<MappingVO> retlist = mappService.getMappedList();
		return retlist;
	}
	
}
