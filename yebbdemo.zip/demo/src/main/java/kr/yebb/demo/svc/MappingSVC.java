package kr.yebb.demo.svc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.yebb.demo.dao.MappingDAO;
import kr.yebb.demo.vo.MappingVO;

@Service
public class MappingSVC {
	
	@Autowired
	MappingDAO mapDAO;
	
	public List<MappingVO> getMappedList() {
		
		return mapDAO.getMappedList();
	}

}
