package kr.yebb.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import kr.yebb.demo.vo.Product;
import kr.yebb.demo.vo.User;

@Repository
public class UserDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<User> getUserist(){
		
		System.out.println("UserDAO");
		String query = "SELECT USERID, USERNAME, PASSWORD, COUNT, CREDIT FROM USER; ";
		RowMapper<User> rowMapper = new BeanPropertyRowMapper<User>(User.class);
		
		return this.jdbcTemplate.query(query, rowMapper);
	}
	
}
