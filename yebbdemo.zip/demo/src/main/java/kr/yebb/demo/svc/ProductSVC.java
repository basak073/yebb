package kr.yebb.demo.svc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.yebb.demo.dao.ProductDAO;
import kr.yebb.demo.vo.Product;

@Service
public class ProductSVC {

	@Autowired
	private ProductDAO productDAO;
	
	public List<Product> getProuductList(){
		//List<Product> tmpList = new ArrayList<Product>();
		
		//this.jdbcTemplate
		return productDAO.getProudctList();
		
	}
	
}
